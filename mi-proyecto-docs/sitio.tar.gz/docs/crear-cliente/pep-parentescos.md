---
title: PEP Parentescos - Persona Natural
hide:
  - toc
  - nav
---
# PEP Parentescos - Persona Natural

Registro de las personas con las que la persona PEP tiene algún parentesco respecto a los grados de consanguinidad indicados en cada sección. 

Cuando el estado civil de la persona es **soltero**, solo será requerido el ingreso de los datos correspondientes a uno de los padres, pero si el estado civil es **casado**, será requerido el ingreso de los datos correspondientes a uno de los padres y uno de los suegros. 

En la sección de padres se utiliza el botón **Guardar** para que los datos sean creados, en las demás secciones de parentescos se debe utilizar el botón **Agregar** y **Guardar** para que los datos sean creados.

El botón **Siguiente** se habilita hasta que sean ingresados los datos de los parentescos obligatorios y los opcionales. 

### Secciones de Parentesco
* [Padres](parentescos-padres.md)
* [Suegros](parentescos-suegros.md)
* [Hijos](parentescos-hijos.md)
* [Hermanos y Abuelos](parentescos-hermanos-abuelos.md)
* [Cuñados](parentescos-cunados.md)

---

[← Volver a página anterior](crear-cliente-natural.md)

<style>
  /* Estilos específicos para Autorizaciones */
  .md-typeset h1 {
    color: #2d5490;
    border-bottom: 3px solid #2d5490;
    padding-bottom: 0.5rem;
  }
  
  .md-typeset h2 {
    color: #3a6bc0;
    margin-top: 2.5rem;
    padding-top: 1rem;
    border-top: 2px solid #eee;
  }
  
  .md-typeset h3 {
    color: #4a7cd0;
    margin-top: 1.8rem;
    padding-left: 1rem;
    border-left: 4px solid #2d5490;
  }
  
  .md-typeset img {
    display: block;
    margin: 2em auto;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
    max-width: 100%;
    height: auto;
    border: 1px solid #ddd;
  }
  
  .md-typeset strong {
    color: #2d5490;
    font-size: 1.1em;
    background-color: #f0f7ff;
    padding: 2px 6px;
    border-radius: 4px;
    display: inline-block;
    margin: 0.5em 0;
  }
  
  /* Estilo para secciones ACEPTAR/RECHAZAR/CANCELAR */
  .md-typeset h3 + p + strong {
    font-size: 1.2em;
    padding: 8px 15px;
    margin: 1.5em 0 1em 0;
    border-left: 5px solid #2d5490;
  }
  
  /* Mejorar legibilidad de párrafos */
  .md-typeset p {
    line-height: 1.6;
    text-align: justify;
    margin-bottom: 1.2em;
  }
  
  /* Estilo para imágenes con ancho específico */
  .md-typeset img[width="400"] {
    max-width: 400px;
    width: 100%;
  }
</style>