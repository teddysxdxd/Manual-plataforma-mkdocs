---
title: Busqueda de clientes
hide:
  - toc
  - nav
---
# Búsqueda de cliente

La búsqueda de clientes es el gestor en el que se centraliza la información de los clientes, facilitando la ubicación de cada persona natural o jurídica, por medio de criterios de búsqueda y filtros que permiten incluir o excluir determinado tipo de personas o clientes. 

![Pantalla Búsqueda de Clientes](../assets/images/plataforma_busqueda_de_cliente.png)

!!! info "Consejo de uso"
    Para ejecutar la búsqueda es necesario ingresar datos en uno de los criterios de búsqueda que dispone el gestor. La búsqueda se ejecuta al utilizar el botón **Buscar** o presionar la tecla **Enter**.

## Tipos de Búsqueda Disponibles

* [Búsqueda por documento de identificación](busqueda-documento.md)
* [Búsqueda por código de cliente](busqueda-codigo.md)
* [Búsqueda por nombres](busqueda-nombres.md)
* [Búsqueda por producto](busqueda-producto.md)
* [Criterios adicionales](criterios.md)

---

## Agregar

El botón **Agregar** se habilita después de haber realizado al menos una búsqueda de personas. Este botón es utilizado para iniciar el flujo de creación de clientes para personas naturales o jurídicas.

Los pasos del flujo de creación de clientes pueden variar dependiendo del tipo de persona y los datos ingresados en cada paso.

!!! warning "Importante"
    En los flujos se permite la navegación entre los pasos por medio de los botones **Anterior** y **Siguiente**. Sin embargo, los datos principales como:
    
    * Documentos de identificación
    * Nombres y apellidos
    * Género o tipo de persona
    
    **No podrán ser modificados** una vez se haya pasado al siguiente paso.

[← Volver a Menú plataforma](../index.md)

<style>
  /* Estilos específicos para Autorizaciones */
  .md-typeset h1 {
    color: #2d5490;
    border-bottom: 3px solid #2d5490;
    padding-bottom: 0.5rem;
  }
  
  .md-typeset h2 {
    color: #3a6bc0;
    margin-top: 2.5rem;
    padding-top: 1rem;
    border-top: 2px solid #eee;
  }
  
  .md-typeset h3 {
    color: #4a7cd0;
    margin-top: 1.8rem;
    padding-left: 1rem;
    border-left: 4px solid #2d5490;
  }
  
  .md-typeset img {
    display: block;
    margin: 2em auto;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
    max-width: 100%;
    height: auto;
    border: 1px solid #ddd;
  }
  
  .md-typeset strong {
    color: #2d5490;
    font-size: 1.1em;
    background-color: #f0f7ff;
    padding: 2px 6px;
    border-radius: 4px;
    display: inline-block;
    margin: 0.5em 0;
  }
  
  /* Estilo para secciones ACEPTAR/RECHAZAR/CANCELAR */
  .md-typeset h3 + p + strong {
    font-size: 1.2em;
    padding: 8px 15px;
    margin: 1.5em 0 1em 0;
    border-left: 5px solid #2d5490;
  }
  
  /* Mejorar legibilidad de párrafos */
  .md-typeset p {
    line-height: 1.6;
    text-align: justify;
    margin-bottom: 1.2em;
  }
  
  /* Estilo para imágenes con ancho específico */
  .md-typeset img[width="400"] {
    max-width: 400px;
    width: 100%;
  }
</style>